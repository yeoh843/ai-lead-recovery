import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';

const app = express();
const PORT = 3000;
const JWT_SECRET = 'your-secret-key-change-in-production';

app.use(cors());
app.use(express.json());

const adapter = new JSONFile('db.json');
const db = new Low(adapter, {});

await db.read();
db.data ||= { users: [], leads: [], sequences: [], sequence_steps: [] };
await db.write();

const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ error: 'No token provided' });

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/api/auth/register', async (req, res) => {
  const { email, password, company_name } = req.body;
  await db.read();
  
  if (db.data.users.find(u => u.email === email)) {
    return res.status(400).json({ error: 'Email already exists' });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const user = {
    id: db.data.users.length + 1,
    email,
    password: hashedPassword,
    company_name: company_name || '',
    created_at: new Date().toISOString()
  };

  db.data.users.push(user);
  await db.write();

  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email: user.email, company_name: user.company_name } });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  await db.read();
  const user = db.data.users.find(u => u.email === email);

  if (!user || !await bcrypt.compare(password, user.password)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email: user.email, company_name: user.company_name } });
});

app.get('/api/auth/me', authenticate, async (req, res) => {
  await db.read();
  const user = db.data.users.find(u => u.id === req.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user: { id: user.id, email: user.email, company_name: user.company_name } });
});

app.get('/api/leads', authenticate, async (req, res) => {
  await db.read();
  const leads = db.data.leads.filter(l => l.user_id === req.userId);
  res.json({ leads });
});

app.post('/api/leads', authenticate, async (req, res) => {
  const { email, first_name, last_name, company, phone } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required' });

  await db.read();
  const lead = {
    id: db.data.leads.length + 1,
    user_id: req.userId,
    email,
    first_name: first_name || '',
    last_name: last_name || '',
    company: company || '',
    phone: phone || '',
    status: 'new',
    ai_intent: null,
    created_at: new Date().toISOString()
  };

  db.data.leads.push(lead);
  await db.write();
  res.json({ lead });
});

app.get('/api/sequences', authenticate, async (req, res) => {
  await db.read();
  const sequences = db.data.sequences.filter(s => s.user_id === req.userId);
  res.json({ sequences });
});

app.post('/api/sequences', authenticate, async (req, res) => {
  const { name, description, steps } = req.body;
  if (!name) return res.status(400).json({ error: 'Sequence name is required' });

  await db.read();
  const sequence = {
    id: db.data.sequences.length + 1,
    user_id: req.userId,
    name,
    description: description || '',
    is_active: true,
    created_at: new Date().toISOString()
  };

  db.data.sequences.push(sequence);

  if (steps && Array.isArray(steps)) {
    steps.forEach((step, index) => {
      db.data.sequence_steps.push({
        id: db.data.sequence_steps.length + 1,
        sequence_id: sequence.id,
        step_number: index + 1,
        delay_days: step.delay_days || 0,
        email_template: step.email_template || ''
      });
    });
  }

  await db.write();
  res.json({ sequence });
});

app.get('/api/analytics/dashboard', authenticate, async (req, res) => {
  await db.read();
  const userLeads = db.data.leads.filter(l => l.user_id === req.userId);
  const userSequences = db.data.sequences.filter(s => s.user_id === req.userId);

  const totalLeads = userLeads.length;
  const repliedLeads = userLeads.filter(l => l.status === 'replied').length;
  const replyRate = totalLeads > 0 ? Math.round((repliedLeads / totalLeads) * 100) : 0;
  
  const funnel = {};
  userLeads.forEach(lead => {
    funnel[lead.status] = (funnel[lead.status] || 0) + 1;
  });

  const hotLeads = userLeads.filter(l => l.ai_intent === 'INTERESTED');

  res.json({
    overview: {
      total_leads: totalLeads,
      reply_rate: replyRate,
      recovered_this_month: hotLeads.length,
      active_sequences: userSequences.filter(s => s.is_active).length
    },
    hot_leads: hotLeads,
    funnel
  });
});

app.listen(PORT, () => {
  console.log(`✅ Backend server running on http://localhost:${PORT}`);
  console.log(`✅ API ready at http://localhost:${PORT}/api`);
});
