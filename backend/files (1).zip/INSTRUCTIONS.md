# HOW TO START YOUR BACKEND SERVER

## Step 1: Open Terminal/Command Prompt

**Windows:**
- Press `Windows Key + R`
- Type `cmd` and press Enter

**Mac:**
- Press `Command + Space`
- Type `terminal` and press Enter

## Step 2: Navigate to Backend Folder

Type this command (one at a time):

```bash
cd Desktop
cd ai-lead-recovery-backend
```

(Replace with wherever you save the backend folder)

## Step 3: Install Dependencies (FIRST TIME ONLY)

Type this command:

```bash
npm install
```

Wait for it to finish (takes 1-2 minutes)

## Step 4: Start the Server

Type this command:

```bash
npm start
```

You should see:
```
✅ Backend server running on http://localhost:3000
✅ API ready at http://localhost:3000/api
```

## Step 5: Open Your Frontend

Now open `index.html` in your browser.

The login page should work now!

---

## Common Issues:

**"npm is not recognized"**
- You need to install Node.js from https://nodejs.org
- Download and install it, then restart your terminal

**"Port 3000 already in use"**
- Close any other programs using port 3000
- Or change PORT to 3001 in server.js

---

## To Stop the Server:

Press `Ctrl + C` in the terminal
